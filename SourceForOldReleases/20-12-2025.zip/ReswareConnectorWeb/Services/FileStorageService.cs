﻿using Microsoft.Extensions.Options;
using Org.BouncyCastle.Asn1.Ocsp;
using ReceiveNoteServiceNS;
using ReswareConnectorWeb.Config;
using ReswareConnectorWeb.Data.Entities;
using ReswareConnectorWeb.Enums;
using System.Globalization;
using System.Text.Json;

namespace ReswareConnectorWeb.Services
{
    public class FileStorageService : IFileStorageService
    {
        private readonly FileStorageConfig _config;

        public FileStorageService(IOptions<FileStorageConfig> config)
        {
            _config = config.Value;
        }
        public async Task<string> StoreTransactionDataAsync<T>(T requestData, TransactionTypeEnum transactionType)
        {
            var relativePath = Path.Combine(transactionType.ToString(), DateTime.Now.ToString("MM-dd-yyyy"), Guid.NewGuid().ToString());
            var targetPath = Path.Combine(_config.LocalStorageRoot, relativePath);
            var targetFile = Path.Combine(targetPath, "Request.json");

            IOHelper.CreateDirectory(targetPath);

            await IOHelper.CreateJsonFileAsync(requestData, targetFile);

            return relativePath;

        }
        public async Task<T> RetrieveTransactionDataAsync<T>(Transaction request)
        {
            var targetPath = Path.Combine(_config.LocalStorageRoot, request.DataPath);
            var targetFile = Path.Combine(targetPath, "Request.json");

            var requestData = await IOHelper.LoadJsonFileAsync<T>(targetFile);

            return requestData;
        }

        public async Task<byte[]> GetDocumentFromTitleHub(string sourceFile)
        {
            var sourceFilePath = Path.Combine(_config.TitleHubDocRoot, sourceFile);
            if(File.Exists(sourceFilePath)) 
            {
                return await IOHelper.ReadAllBytesAsync(sourceFilePath);
            }
            throw new FileNotFoundException($"File '{sourceFilePath}' not found!");
        }

        public async Task RemoveTransactionDataAsync(Transaction request)
        {
            await Task.Run(() =>
            {
                var targetPath = Path.Combine(_config.LocalStorageRoot, request.DataPath);
                Directory.Delete(targetPath, true);
                var parentDir = Directory.GetParent(targetPath)?.FullName;
                if(!string.IsNullOrEmpty(parentDir) && Directory.GetDirectories(parentDir).Length == 0)
                {
                    Directory.Delete(parentDir);
                }
            });
        }

        /*
        public async Task CleanupTransactionDataAsync(DateOnly cutoffDate)
        {
            _logger.LogInformation("Applying Transaction File Retention Policy");
            await Task.Run(() =>
            {
                try
                {
                    var folderGroups = Directory.GetDirectories(_config.LocalStorageRoot);


                    foreach (var folder in folderGroups)
                    {
                        var datewiseFoldersToDelete = Directory.GetDirectories(folder);
                        foreach (var dateFolder in datewiseFoldersToDelete)
                        {
                            try
                            {
                                var folderName = Path.GetFileName(dateFolder);
                                if (DateTime.TryParseExact(folderName, "MM-dd-yyyy",
                                    CultureInfo.InvariantCulture, DateTimeStyles.None, out var folderDate))
                                {
                                    if (DateOnly.FromDateTime(folderDate) < cutoffDate)
                                    {
                                        Directory.Delete(dateFolder, recursive: true);
                                        _logger.LogInformation($"Deleted folder: {dateFolder}");
                                    }
                                }
                                else
                                {
                                    _logger.LogInformation($"Skipping folder with invalid date format: {folderName}");
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, $"Error deleting folder {dateFolder}: {ex.Message}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"Unknow error: {ex.Message}");
                }
            });
            _logger.LogInformation("Applying Transaction File Retention Policy - Completed");
        }
        */
    }
}
