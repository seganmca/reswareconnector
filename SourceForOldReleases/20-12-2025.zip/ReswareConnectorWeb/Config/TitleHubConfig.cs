﻿namespace ReswareConnectorWeb.Config
{
    public class TitleHubConfig
    {
        public required string BaseUrl { get; set; }
        public RetryPolicyConfig RetryPolicy { get; set; } = new();
    }
}
