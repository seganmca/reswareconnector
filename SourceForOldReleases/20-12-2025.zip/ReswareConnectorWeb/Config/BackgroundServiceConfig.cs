﻿namespace ReswareConnectorWeb.Config
{
    public class BackgroundServiceConfig
    {
        public int MaxRetryAttemptsPerTransaction { get; set; } = 5;
        public TimeSpan SleepInterval { get; set; } = TimeSpan.FromMinutes(5);
        public RetentionPolicyConfig RetentionPolicy { get; set; } = new();
    }
}
