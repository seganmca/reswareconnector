﻿namespace ReswareConnectorWeb.Enums
{

}
